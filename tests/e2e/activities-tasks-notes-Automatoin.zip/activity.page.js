// pages/shared/activity.page.js
// ─────────────────────────────────────────────────────────────────────────────
//  SHARED Activity Page Object — verified live across all 4 modules
//
//  Module      | Tab name     | Default selected?
//  ────────────|──────────────|───────────────────
//  Contacts    | "Activities" | YES — default tab
//  Deals       | "Activities" | NO  — "Contract & Terms" is default
//  Properties  | "Activities" | NO  — "Convert Questions" is default
//  Companies   | "Activities" | YES — default tab
//
//  KEY FACTS (live-verified):
//  • Tab role            : tab, name "Activities"
//  • tabpanel role       : tabpanel, name "Activities"
//  • Activities are READ-ONLY — no "Create Activity" button exists anywhere
//  • Feed is date-grouped with paragraphs like "July, 2025", "March, 2026"
//  • Each activity entry has: author line, timestamp (generic), description paragraph
//  • Contacts entry text: "Contact Added", "Note added from Hubspot", "Contact Added by HubSpot"
//  • Company entry text: "Company created", "A-C 6548 company synced from HubSpot"
// ─────────────────────────────────────────────────────────────────────────────

const { expect } = require('@playwright/test');

class ActivityPage {
  constructor(page) {
    this.page = page;

    // ── Tab ──────────────────────────────────────────────────────────────────
    this.activitiesTab = page.getByRole('tab', { name: 'Activities' });

    // ── Tab panel ─────────────────────────────────────────────────────────────
    this.activityPanel = page.getByRole('tabpanel', { name: 'Activities' });
  }

  // ── Navigation ─────────────────────────────────────────────────────────────

  async goToActivitiesTab() {
    await this.activitiesTab.click();
    await expect(this.activitiesTab).toHaveAttribute('aria-selected', 'true', { timeout: 5000 });
  }

  // ── Assertions ─────────────────────────────────────────────────────────────

  async assertActivitiesTabVisible() {
    await expect(this.activitiesTab).toBeVisible();
  }

  async assertActivitiesTabActive() {
    await expect(this.activitiesTab).toHaveAttribute('aria-selected', 'true');
  }

  async assertActivityPanelVisible() {
    await expect(this.activityPanel).toBeVisible();
  }

  /**
   * Assert at least one date-group header exists (e.g. "July, 2025").
   * The app groups activities by "Month, Year" paragraphs.
   */
  async assertAtLeastOneActivity() {
    // Date headers are paragraphs with text like "July, 2025" or "March, 2026"
    const dateHeaders = this.page.getByText(/^[A-Z][a-z]+,\s+\d{4}$/);
    await expect(dateHeaders.first()).toBeVisible({ timeout: 8000 });
  }

  /**
   * Assert a specific text string appears anywhere in the activities feed.
   * @param {string} text - e.g. 'Contact Added', 'Note added from Hubspot'
   */
  async assertActivityContains(text) {
    await expect(
      this.activityPanel.getByText(text, { exact: false })
    ).toBeVisible({ timeout: 8000 });
  }

  /**
   * Assert "Activities" tab is visible on the page.
   * Does NOT click it — just checks presence.
   */
  async assertTabPresent() {
    await expect(this.activitiesTab).toBeVisible();
  }
}

module.exports = { ActivityPage };
