// pages/shared/tasks.page.js
// ─────────────────────────────────────────────────────────────────────────────
//  SHARED Tasks Page Object — verified live across ALL 4 modules
//
//  Module         | Tab name  | URL pattern
//  ────────────────|───────────|──────────────────────────────────
//  Contacts        | "Tasks"   | /contacts/detail/:id
//  Deals           | "Tasks"   | /deals/deal/:id
//  Properties      | "Tasks"   | /locations/location/:id
//  Companies       | "Tasks"   | /companies/company/:id
//
//  KEY LOCATOR FACTS (live-verified — do NOT change):
//
//  DRAWER FIELDS
//  ─────────────
//  • Drawer heading     : "Create New Task" (heading level=3)
//  • Task Title         : textbox named "Task Title"  ← has a proper label
//  • Description        : textbox named "rdw-editor"  (rich text)
//  • char counter       : paragraph text matching /\d+ \/ 500/  (NOT 5000 — Tasks uses 500)
//  • Type dropdown      : custom div — click heading "Select Type" (level=6)
//                         opens a tooltip with paragraph options: "To-do" | "Email" | "Call" | "LinkedIn"
//  • Priority dropdown  : custom div — click heading "Select Priority" (level=6)
//                         opens a tooltip with paragraph options: "High" | "Medium" | "Low"
//  • Due Date           : textbox with current date/time as value (e.g. "03/20/2026 08:52 PM")
//                         — has NO placeholder in drawer; use getByRole('textbox') scoped to drawer
//  • Save / Cancel      : "Save" / "Cancel" buttons
//
//  TABLE FILTERS (on Tasks tab, NOT in the drawer)
//  ─────────────
//  • Type filter    : heading "Type" (level=6) inside the tab panel
//  • Priority filter: heading "Priority" (level=6) inside the tab panel
//  • Status filter  : heading "Status" (level=6) inside the tab panel
//  • Date range     : textbox with placeholder "MM/DD/YYYY - MM/DD/YYYY"
//  • Search         : searchbox "Search by Title"
// ─────────────────────────────────────────────────────────────────────────────

const { expect } = require('@playwright/test');

class TasksPage {
  constructor(page) {
    this.page = page;

    // ── Tab ──────────────────────────────────────────────────────────────────
    this.tasksTab = page.getByRole('tab', { name: /^Tasks/ });

    // ── Toolbar (inside the Tasks tabpanel) ───────────────────────────────────
    this.newTaskBtn       = page.getByRole('button',    { name: 'New Task' });
    this.searchByTitleBox = page.getByRole('searchbox', { name: 'Search by Title' });

    // Filter buttons in the Tasks list toolbar — these are heading elements
    // inside generic divs, NOT buttons — use getByRole('heading', ...)
    this.typeFilterTrigger     = page.getByRole('heading', { name: 'Type',     level: 6 }).first();
    this.priorityFilterTrigger = page.getByRole('heading', { name: 'Priority', level: 6 }).first();
    this.statusFilterTrigger   = page.getByRole('heading', { name: 'Status',   level: 6 });

    // Date range filter — has placeholder "MM/DD/YYYY - MM/DD/YYYY" (only on the LIST toolbar)
    this.dateRangeInput = page.getByRole('textbox', { name: /MM\/DD\/YYYY/ });

    // ── Create / Edit Task drawer ─────────────────────────────────────────────
    this.createDrawerHeading = page.getByRole('heading', { name: 'Create New Task', level: 3 });

    // Task Title — properly labelled, safe to use getByRole
    this.taskTitleInput = page.getByRole('textbox', { name: 'Task Title' });

    // Description — rich text editor
    this.descriptionEditor = page.getByRole('textbox', { name: 'rdw-editor' });

    // char counter shows "0 / 500" (Tasks uses 500 limit, Notes uses 5000)
    this.charCounter = page.getByText(/\d+ \/ 500/);

    // Type & Priority — custom dropdown: clicking the heading opens a tooltip
    // The heading text changes once selected (e.g. "Call", "High")
    // Use the wrapper div to click, then select from the tooltip paragraphs
    this.typeDropdownTrigger     = page.getByRole('heading', { name: 'Select Type',     level: 6 });
    this.priorityDropdownTrigger = page.getByRole('heading', { name: 'Select Priority', level: 6 });

    // Type option values: 'To-do' | 'Email' | 'Call' | 'LinkedIn'
    // Priority option values: 'High' | 'Medium' | 'Low'
    // Options appear inside a tooltip — use getByRole('tooltip') or getByText()
    this.typeTooltip     = page.getByRole('tooltip').filter({ hasText: /To-do/ });
    this.priorityTooltip = page.getByRole('tooltip').filter({ hasText: /High/ });

    // Due Date textbox inside the drawer — scoped to avoid clash with date range on list
    // It shows the current date/time as value, has no placeholder
    this.dueDateDrawerInput = page.getByRole('textbox').filter({ hasValue: /\d{2}\/\d{2}\/\d{4}/ });

    this.saveBtn   = page.getByRole('button', { name: 'Save' });
    this.cancelBtn = page.getByRole('button', { name: 'Cancel' });

    // ── Tasks table ───────────────────────────────────────────────────────────
    this.tasksTable        = page.getByRole('table');
    this.emptyStateHeading = page.getByRole('heading', { name: 'No tasks Added.', level: 2 });
    this.paginationInfo    = page.getByText(/\d+–\d+ of \d+/);
    this.nextPageBtn       = page.getByRole('button', { name: 'Go to next page' });
    this.prevPageBtn       = page.getByRole('button', { name: 'Go to previous page' });
    this.rowsPerPage       = page.getByRole('combobox', { name: /Rows per page/ });
  }

  // ── Tab navigation ─────────────────────────────────────────────────────────

  async goToTasksTab() {
    await this.tasksTab.click();
    await expect(this.newTaskBtn).toBeVisible({ timeout: 8000 });
  }

  // ── Create Task ───────────────────────────────────────────────────────────

  async openCreateTaskDrawer() {
    await this.newTaskBtn.click();
    await expect(this.createDrawerHeading).toBeVisible({ timeout: 6000 });
  }

  /**
   * Fill the task form.
   * @param {Object} data
   * @param {string}  data.title        - Required
   * @param {string}  [data.description] - Rich text body
   * @param {string}  [data.type]        - 'To-do' | 'Email' | 'Call' | 'LinkedIn'
   * @param {string}  [data.priority]    - 'High' | 'Medium' | 'Low'
   */
  async fillTaskForm({ title, description, type, priority }) {
    if (title) {
      await this.taskTitleInput.fill(title);
    }

    if (description) {
      await this.descriptionEditor.click();
      await this.descriptionEditor.fill(description);
    }

    // Type — click trigger heading, then click the paragraph option in the tooltip
    if (type) {
      await this.typeDropdownTrigger.click();
      await this.page.getByRole('tooltip').getByText(type, { exact: true }).click();
    }

    // Priority — click trigger heading, then click the paragraph option in the tooltip
    if (priority) {
      await this.priorityDropdownTrigger.click();
      await this.page.getByRole('tooltip').getByText(priority, { exact: true }).click();
    }
  }

  async submitTaskForm() {
    await this.saveBtn.click();
    await expect(this.createDrawerHeading).not.toBeVisible({ timeout: 8000 });
  }

  async cancelTaskForm() {
    await this.cancelBtn.click();
    await expect(this.createDrawerHeading).not.toBeVisible({ timeout: 5000 });
  }

  /** Full create-task helper (open → fill → save) */
  async createTask(taskData) {
    await this.openCreateTaskDrawer();
    await this.fillTaskForm(taskData);
    await this.submitTaskForm();
  }

  // ── Search & Filter ────────────────────────────────────────────────────────

  async searchTask(term) {
    await this.searchByTitleBox.fill(term);
    await this.page.waitForTimeout(500);
  }

  async clearTaskSearch() {
    await this.searchByTitleBox.clear();
    await this.page.waitForTimeout(500);
  }

  // ── Assertions ─────────────────────────────────────────────────────────────

  async assertTasksTabVisible() {
    await expect(this.tasksTab).toBeVisible();
  }

  async assertTasksTabActive() {
    await expect(this.tasksTab).toHaveAttribute('aria-selected', 'true');
  }

  /** Verify all 6 required column headers are present */
  async assertTableColumns() {
    const expectedCols = [
      'Task Title',
      'Task Description',
      'Created By',
      'Due Date',
      'Priority',
      'Type',
    ];
    for (const col of expectedCols) {
      await expect(
        this.page.getByRole('columnheader', { name: col })
      ).toBeVisible();
    }
  }

  async assertEmptyState() {
    await expect(this.emptyStateHeading).toBeVisible();
  }

  async assertTaskVisible(taskTitle) {
    await expect(
      this.page.getByRole('cell', { name: taskTitle })
    ).toBeVisible({ timeout: 8000 });
  }

  async assertTaskNotVisible(taskTitle) {
    await expect(
      this.page.getByRole('cell', { name: taskTitle })
    ).not.toBeVisible();
  }

  async assertCreateDrawerOpen() {
    await expect(this.createDrawerHeading).toBeVisible();
  }

  async assertCreateDrawerClosed() {
    await expect(this.createDrawerHeading).not.toBeVisible();
  }

  async assertFilterButtonsVisible() {
    await expect(this.typeFilterTrigger).toBeVisible();
    await expect(this.priorityFilterTrigger).toBeVisible();
    await expect(this.statusFilterTrigger).toBeVisible();
  }

  async assertNewTaskBtnVisible() {
    await expect(this.newTaskBtn).toBeVisible();
  }

  async assertCharCounterVisible() {
    await expect(this.charCounter).toBeVisible();
  }
}

module.exports = { TasksPage };
