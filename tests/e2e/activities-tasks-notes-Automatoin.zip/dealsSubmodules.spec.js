// tests/dealsSubmodules.spec.js
// ─────────────────────────────────────────────────────────────────────────────
//  REUSE DEMO — Deals Module: Notes & Tasks smoke tests
//
//  This spec proves the SHARED page objects work unchanged for Deals.
//  Zero code duplication — same NotesPage and TasksPage classes.
//
//  Deal URL pattern confirmed: /app/sales/deals/deal/:id
//  Verified deal ID 18619 ("Mobile regression deal 1") during MCP exploration.
//
//  Tab structure on Deals detail (live-verified):
//    "Contract & Terms" | "Activities" | "Notes" | "Tasks"
//    → Notes tab name: plain "Notes" (no count badge)
//    → Tasks tab name: plain "Tasks"
// ─────────────────────────────────────────────────────────────────────────────

const { test, expect } = require('@playwright/test');
const { LoginPage }  = require('../pages/login.page');
const { NotesPage }  = require('../pages/shared/notes.page');
const { TasksPage }  = require('../pages/shared/tasks.page');
const { ActivityPage } = require('../pages/shared/activity.page');
const { TEST_CREDENTIALS } = require('../fixtures/testData');

// Verified deal detail URL from live MCP exploration
const DEAL_DETAIL_URL = '/app/sales/deals/deal/18619';

test.beforeEach(async ({ page }) => {
  const loginPage = new LoginPage(page);
  await loginPage.login(TEST_CREDENTIALS.email, TEST_CREDENTIALS.password);
  await page.goto(DEAL_DETAIL_URL);
  await page.waitForURL(/\/deals\/deal\//);
});

// ═══════════════════════════════════════════════════════════════════════════
//  ACTIVITY — Deals Module
// ═══════════════════════════════════════════════════════════════════════════
test.describe('Deals Submodule — Activity (Shared POM reuse)', () => {

  /**
   * TC-DEAL-ACT-001
   * Activities tab is visible on Deal detail
   * (Same ActivityPage class as Contacts — zero duplication)
   */
  test('TC-DEAL-ACT-001 — Activities tab visible on Deal detail', async ({ page }) => {
    const activityPage = new ActivityPage(page);
    await activityPage.assertActivitiesTabVisible();
  });

  /**
   * TC-DEAL-ACT-002
   * Activities tab can be clicked and panel appears on Deals
   * NOTE: "Contract & Terms" is the default tab on Deals — Activities is NOT selected by default
   */
  test('TC-DEAL-ACT-002 — Activities panel renders on Deal detail', async ({ page }) => {
    const activityPage = new ActivityPage(page);
    await activityPage.goToActivitiesTab();
    await activityPage.assertActivityPanelVisible();
  });

});

// ═══════════════════════════════════════════════════════════════════════════
//  NOTES — Deals Module
// ═══════════════════════════════════════════════════════════════════════════
test.describe('Deals Submodule — Notes (Shared POM reuse)', () => {

  /**
   * TC-DEAL-NOTE-001
   * Notes tab is visible on Deal detail
   * (Plain "Notes" — no count badge on Deals)
   */
  test('TC-DEAL-NOTE-001 — Notes tab visible on Deal detail', async ({ page }) => {
    const notesPage = new NotesPage(page);
    await notesPage.assertNotesTabVisible();
    await expect(notesPage.notesTab).toContainText('Notes');
  });

  /**
   * TC-DEAL-NOTE-002
   * Clicking Notes tab shows Create New Note button
   */
  test('TC-DEAL-NOTE-002 — Notes tab shows Create New Note button on Deal', async ({ page }) => {
    const notesPage = new NotesPage(page);
    await notesPage.goToNotesTab();
    await notesPage.assertCreateButtonVisible();
  });

  /**
   * TC-DEAL-NOTE-003
   * Create New Note drawer opens on Deal detail with same structure
   */
  test('TC-DEAL-NOTE-003 — Create Note drawer opens on Deal detail', async ({ page }) => {
    const notesPage = new NotesPage(page);
    await notesPage.goToNotesTab();
    await notesPage.openCreateNoteDrawer();

    // Same drawer heading "Add Notes" — confirmed identical across modules
    await expect(notesPage.drawerHeading).toBeVisible();
    await expect(notesPage.subjectInput).toBeVisible();
    await expect(notesPage.saveBtn).toBeVisible();
    await expect(notesPage.cancelBtn).toBeVisible();
  });

  /**
   * TC-DEAL-NOTE-004
   * Cancel button closes the drawer on Deal detail
   */
  test('TC-DEAL-NOTE-004 — Cancel Create Note closes drawer on Deal', async ({ page }) => {
    const notesPage = new NotesPage(page);
    await notesPage.goToNotesTab();
    await notesPage.openCreateNoteDrawer();
    await notesPage.cancelNoteForm();
    await notesPage.assertDrawerClosed();
  });

});

// ═══════════════════════════════════════════════════════════════════════════
//  TASKS — Deals Module
// ═══════════════════════════════════════════════════════════════════════════
test.describe('Deals Submodule — Tasks (Shared POM reuse)', () => {

  /**
   * TC-DEAL-TASK-001
   * Tasks tab is visible on Deal detail
   */
  test('TC-DEAL-TASK-001 — Tasks tab visible on Deal detail', async ({ page }) => {
    const tasksPage = new TasksPage(page);
    await tasksPage.assertTasksTabVisible();
  });

  /**
   * TC-DEAL-TASK-002
   * Tasks table shows all correct columns on Deal detail
   */
  test('TC-DEAL-TASK-002 — Tasks table columns correct on Deal detail', async ({ page }) => {
    const tasksPage = new TasksPage(page);
    await tasksPage.goToTasksTab();
    await tasksPage.assertTableColumns();
  });

  /**
   * TC-DEAL-TASK-003
   * New Task drawer opens on Deal detail with correct fields
   */
  test('TC-DEAL-TASK-003 — New Task drawer opens on Deal detail', async ({ page }) => {
    const tasksPage = new TasksPage(page);
    await tasksPage.goToTasksTab();
    await tasksPage.openCreateTaskDrawer();
    await tasksPage.assertCreateDrawerOpen();

    // Same Type/Priority structure — verify they are present
    await expect(tasksPage.typeDropdownTrigger).toBeVisible();
    await expect(tasksPage.priorityDropdownTrigger).toBeVisible();
  });

  /**
   * TC-DEAL-TASK-004
   * Cancel closes the Create Task drawer on Deal detail
   */
  test('TC-DEAL-TASK-004 — Cancel Create Task closes drawer on Deal', async ({ page }) => {
    const tasksPage = new TasksPage(page);
    await tasksPage.goToTasksTab();
    await tasksPage.openCreateTaskDrawer();
    await tasksPage.cancelTaskForm();
    await tasksPage.assertCreateDrawerClosed();
  });

});
