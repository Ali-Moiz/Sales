// pages/shared/notes.page.js
// ─────────────────────────────────────────────────────────────────────────────
//  SHARED Notes Page Object — verified live across all 4 modules
//
//  Module         | Tab name        | tabpanel name  | URL pattern
//  ────────────────|─────────────────|────────────────|──────────────────────
//  Contacts        | "Notes 1" (badge)| "Notes 1"     | /contacts/detail/:id
//  Deals           | "Notes"         | "Notes"        | /deals/deal/:id
//  Properties      | "Notes"         | "Notes"        | /locations/location/:id
//  Companies       | "Notes"         | "Notes"        | /companies/company/:id
//
//  KEY LOCATOR FACTS (from live MCP exploration — do NOT change):
//  • Notes drawer heading  : "Add Notes"  (level=4) — NOT "Create New Note"
//  • Subject field         : unlabelled textbox — use page.locator('[role="generic"] textbox').first()
//                            scoped INSIDE the "Add Notes" drawer
//  • Description editor    : textbox named "rdw-editor"
//  • char counter          : paragraph text matching /\d+ \/ 5000/
//  • Save / Cancel buttons : "Save" / "Cancel"
//  • Delete button name    : "delete" (lowercase 'd' in accessibility tree)
// ─────────────────────────────────────────────────────────────────────────────

const { expect } = require('@playwright/test');

class NotesPage {
  constructor(page) {
    this.page = page;

    // ── Tab ─────────────────────────────────────────────────────────────────
    // Works for both "Notes" (Deals/Properties/Companies) and "Notes 1" (Contacts)
    this.notesTab = page.getByRole('tab', { name: /^Notes/ });

    // ── Toolbar button (visible above the tab content when Notes tab is active)
    this.createNewNoteBtn = page.getByRole('button', { name: 'Create New Note' });

    // ── "Add Notes" drawer ───────────────────────────────────────────────────
    // Drawer container — used to scope Subject input
    this.addNotesDrawer   = page.getByRole('generic', { name: 'Add Notes' });
    // Heading inside drawer (level=4, NOT the tab button)
    this.drawerHeading    = page.getByRole('heading', { name: 'Add Notes', level: 4 });
    // Subject: plain unlabelled textbox — scoped inside drawer to avoid clashes
    this.subjectInput     = page.getByRole('generic', { name: 'Add Notes' })
                                .getByRole('textbox').first();
    // Description: rich-text editor
    this.descriptionEditor = page.getByRole('textbox', { name: 'rdw-editor' });
    // Character counter shown as "0 / 5000"
    this.charCounter       = page.getByText(/\d+ \/ 5000/);
    this.saveBtn           = page.getByRole('button', { name: 'Save' });
    this.cancelBtn         = page.getByRole('button', { name: 'Cancel' });

    // ── Notes list ────────────────────────────────────────────────────────────
    // Each note card has exactly one Edit and one Delete button
    // NOTE: Delete accessible name is lowercase "delete" — verified in app
    this.editNoteBtn   = page.getByRole('button', { name: /^Edit$/ });
    this.deleteNoteBtn = page.getByRole('button', { name: /^[Dd]elete$/ });

    // ── Empty state (Properties/Deals/Companies when 0 notes) ────────────────
    this.emptyStateText = page.getByText('Oops, It\'s Empty Here!');
  }

  // ── Tab navigation ─────────────────────────────────────────────────────────

  /** Switch to the Notes tab on any module detail page */
  async goToNotesTab() {
    await this.notesTab.click();
    await expect(this.createNewNoteBtn).toBeVisible({ timeout: 8000 });
  }

  // ── Create Note ───────────────────────────────────────────────────────────

  async openCreateNoteDrawer() {
    await this.createNewNoteBtn.click();
    await expect(this.drawerHeading).toBeVisible({ timeout: 6000 });
  }

  /**
   * Fill the note form.
   * @param {{ subject: string, description?: string }} data
   */
  async fillNoteForm({ subject, description }) {
    await this.subjectInput.fill(subject);
    if (description) {
      await this.descriptionEditor.click();
      await this.descriptionEditor.fill(description);
    }
  }

  async submitNoteForm() {
    await this.saveBtn.click();
    await expect(this.drawerHeading).not.toBeVisible({ timeout: 8000 });
  }

  async cancelNoteForm() {
    await this.cancelBtn.click();
    await expect(this.drawerHeading).not.toBeVisible({ timeout: 5000 });
  }

  /** Full create-note helper (open → fill → save) */
  async createNote(noteData) {
    await this.openCreateNoteDrawer();
    await this.fillNoteForm(noteData);
    await this.submitNoteForm();
  }

  // ── Edit Note ─────────────────────────────────────────────────────────────

  /**
   * Click the Edit button on the nth note card (0-based).
   * Uses .nth(index) since multiple cards can exist.
   */
  async openEditNote(index = 0) {
    await this.editNoteBtn.nth(index).click();
    await expect(this.drawerHeading).toBeVisible({ timeout: 6000 });
  }

  async submitEditNote() {
    await this.saveBtn.click();
    await expect(this.drawerHeading).not.toBeVisible({ timeout: 8000 });
  }

  // ── Delete Note ───────────────────────────────────────────────────────────

  async clickDeleteNote(index = 0) {
    await this.deleteNoteBtn.nth(index).click();
    // Caller handles any confirmation dialog
  }

  // ── Assertions ────────────────────────────────────────────────────────────

  async assertNotesTabVisible() {
    await expect(this.notesTab).toBeVisible();
  }

  async assertNotesTabActive() {
    await expect(this.notesTab).toHaveAttribute('aria-selected', 'true');
  }

  async assertCreateButtonVisible() {
    await expect(this.createNewNoteBtn).toBeVisible();
  }

  async assertDrawerOpen() {
    await expect(this.drawerHeading).toBeVisible();
  }

  async assertDrawerClosed() {
    await expect(this.drawerHeading).not.toBeVisible();
  }

  async assertCharCounterVisible() {
    await expect(this.charCounter).toBeVisible();
  }

  async assertNoteVisible(subjectText) {
    await expect(this.page.getByText(subjectText)).toBeVisible({ timeout: 8000 });
  }

  /**
   * Assert Notes tab badge count equals expectedCount.
   * Contacts shows "Notes 1", others show plain "Notes" (no count).
   * @param {number} expectedCount
   */
  async assertNoteCount(expectedCount) {
    await expect(this.notesTab).toContainText(String(expectedCount));
  }

  async assertEmptyStateVisible() {
    await expect(this.emptyStateText).toBeVisible();
  }

  async assertEditAndDeleteButtonsVisible() {
    await expect(this.editNoteBtn.first()).toBeVisible();
    await expect(this.deleteNoteBtn.first()).toBeVisible();
  }
}

module.exports = { NotesPage };
